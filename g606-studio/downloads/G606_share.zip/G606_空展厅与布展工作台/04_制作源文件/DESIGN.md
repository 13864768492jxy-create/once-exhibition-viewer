---
name: G606 工作台
description: 继承既有布展编辑器的空间、清单与参数布局。
colors:
  green: "#355a46"
  green-hover: "#264738"
  green-light: "#e8eee7"
  paper: "#f9f8f3"
  panel: "#fcfbf8"
  stage: "#e8e7e0"
  ink: "#25392f"
  muted: "#58675d"
  line: "#d6dad2"
  field: "#ffffff"
  control-hover: "#eeeee8"
  selection-line: "#d8e4d7"
  focus: "#447454"
typography:
  workspace-title:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "23px"
    fontWeight: 500
    lineHeight: 1.3
    letterSpacing: "0"
  dialog-title:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "22px"
    fontWeight: 500
    letterSpacing: "0"
  object-title:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "17px"
    fontWeight: 400
  body:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "13px"
    fontWeight: 400
  supporting-copy:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "12px"
    fontWeight: 400
    lineHeight: 1.65
  field-label:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "12px"
    fontWeight: 400
    lineHeight: 1.5
  metadata:
    fontFamily: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "11px"
    fontWeight: 400
rounded:
  field: "6px"
  control: "7px"
  floating-strip: "8px"
  view-switch: "9px"
  mobile-inspector: "10px"
  dialog: "14px"
spacing:
  compact: "4px"
  related: "6px"
  control: "8px"
  field: "10px"
  group: "12px"
  section: "20px"
components:
  button-primary:
    backgroundColor: "{colors.green}"
    textColor: "{colors.field}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "10px 13px"
  button-primary-hover:
    backgroundColor: "{colors.green-hover}"
  button-secondary:
    backgroundColor: "{colors.panel}"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "10px 13px"
  button-secondary-hover:
    backgroundColor: "{colors.control-hover}"
  button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "10px 13px"
  button-add-art:
    backgroundColor: "{colors.green}"
    textColor: "{colors.field}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "13px"
  input-default:
    backgroundColor: "{colors.field}"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.field}"
    padding: "10px"
  view-active:
    backgroundColor: "{colors.green}"
    textColor: "{colors.field}"
    rounded: "{rounded.field}"
    padding: "8px 12px"
  work-selected:
    backgroundColor: "{colors.green-light}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "10px 7px"
  dialog-default:
    backgroundColor: "{colors.panel}"
    textColor: "{colors.ink}"
    rounded: "{rounded.dialog}"
    padding: "28px"
    width: "470px"
---

# Design System: G606 工作台

## Overview

**Creative North Star: "以真实比例空间为中心的布展工具"**

继承既有布展编辑器的布局与绿色控制色：左侧作品清单，中部真实比例三维视口，右侧选中作品参数。纸白控制面板、浅灰展厅背景和紧凑的中文工具文字围绕实际模型工作。这是分享与尺寸功能的延伸，不另立视觉主题。

本文根据最终的 `site/style.css`、`site/index.html`、`site/app.js` 与抽样的 `site/scene.js` 合并记录；后写的 CSS 覆盖规则优先。这里的方向描述延续原设计记录，字号与组件值来自成品。产品能力与验证范围见 `.impeccable/surface.md`、`qa/documentation-review.md`。

**Key Characteristics:**

- 真实比例模型占据主要工作区。
- 纸白面板承载操作，深绿色标记主要动作与当前视图。
- 中文标签直接说明动作，厘米字段与模型米制明确区分。
- 手机保留四个顶部入口，作品清单移动到展厅下方。

## Colors

低饱和绿色与温和的中性色延续原编辑器；图片本身的色彩由作品决定。

### Primary

- **操作绿**（`green`）：添加图片、打包分享、确认按钮和当前观看方式。
- **按下前的深绿**（`green-hover`）：主要按钮悬停状态。
- **浅绿选择面**（`green-light`）：选中的作品行和墙面视图；作品行以 `selection-line` 描边。
- **焦点绿**（`focus`）：键盘可见焦点轮廓。

### Neutral

- **纸白**（`paper`）与**面板白**（`panel`）：页面及控制侧栏、对话框。
- **场景灰**（`stage`）：三维视口背景；Three.js 场景也使用同一值。
- **深墨绿**（`ink`）与**辅助灰绿**（`muted`）：主要文本与说明、单位、计数。
- **细线灰**（`line`）：侧栏边界、字段和表格分隔。
- **字段白**（`field`）与**悬停浅灰**（`control-hover`）：表单输入及次要按钮反馈。

**The 操作绿 Rule.** 绿色用于动作和选择状态；照片与空间材质保留自身颜色。

## Typography

**Body Font:** 现有系统中文无衬线栈，精确值见 frontmatter。没有独立的展示字体；标题仍是工具界面层级，不是新的品牌字型。

**Label/Mono Font:** 单位与数字沿用正文栈；输入框、列表编号与尺寸表数值列使用 `tabular-nums`。自定义轮廓文本框保留 `monospace`。

### Hierarchy

- **工作区标题**：`workspace-title`；常规桌面为 23px，1150px 及以下为 21px，手机隐藏该标题区域。
- **对话框标题**：`dialog-title`；22px，500。空选择状态标题是 20px，500。
- **作品名称与资料分组**：17px。名称输入框是常规字重；尺寸资料的分组标题保留浏览器 `h3` 默认粗体，不将二者的字重合并成一个规则。
- **正文、数值与主要操作**：`body`；13px。主要输入字段保留等宽数字，表单标签使用 `field-label`。
- **辅助说明与单位**：`supporting-copy`；12px，行高 1.65。选中作品编号已统一为 12px。
- **紧凑元信息**：`metadata`；11px，见作品列表编号、场地摘要、场景提示和手机视图按钮。

没有统一的数学字号比例。原“正常文字至少 12px”是过宽的概括：成品存在上述 11px 辅助层级。少量遗留的 11px 操作与复选标签列入文档检查记录，不由本次记录确立为新增控件的字号标准。

## Layout

桌面为顶栏加三列工作区。顶栏高 83px；通常三列宽度为 `270px minmax(300px, 1fr) 252px`。作品清单和参数侧栏各自滚动，视口填满中列。控制与墙面视图条浮在空间上方，不以卡片包裹模型。

| 视口范围 | 已实现的布局 |
| --- | --- |
| 1600px 及以上 | 三列为 `290px minmax(300px, 1fr) 276px`。 |
| 1150px 及以下 | 三列为 `210px minmax(260px, 1fr) 235px`；收紧侧栏与顶栏间隔。 |
| 850px 及以下 | 顶栏高 70px；两列为 `190px minmax(250px, 1fr)`；参数面板改为选中后打开的覆盖层。 |
| 600px 及以下 | 顶栏最小高度 104px；四个操作入口横排；视口在上，横向作品清单在下；工作区最小高度 650px，视口最小高度 400px。参数面板可独立滚动。 |

间距使用实际的紧凑步长，未形成单一倍数网格。字段组通常间隔 9px，手机为 6px；标准按钮内边距为 10px 13px，顶栏为 10px 12px，主添加按钮为 13px。桌面侧栏约 20px 水平留白，手机清单为 12px。

尺寸资料对话框宽度为 1050px，并受视口宽度减 24px 的上限约束；手机内边距为 18px。平面图保持纵横比缩放，表格容器允许横向滚动。打印样式采用 A4 横向与 12mm 页边距；此处记录样式定义，不代替打印实测。

## Elevation & Depth

常驻侧栏和作品行主要依靠底色与细边线区分。浮动视图条、手机参数面板、移动控件、下载提示与对话框使用轻软阴影；三维空间的光照与阴影来自 Three.js 场景。

对话框使用扩散阴影（`0 14px 65px #152c2328`）和半透明遮罩（`#34443d66`），最终样式不使用背景模糊。字段聚焦使用边线与柔和外环，键盘焦点另有 2px 轮廓和 3px 偏移。完整阴影与焦点代码在 `.impeccable/design.json`。

按钮只有背景色的短过渡（0.15s，默认 ease）；`prefers-reduced-motion` 会关闭 CSS 过渡。三维相机的阻尼属于既有交互，当前 CSS 的减弱动态规则不控制它；不记录为已实现的全局无动态模式。

## Shapes

控件为轻微圆角矩形。输入框与视图内按钮使用 `field` 圆角，普通按钮与作品行使用 `control` 圆角；对话框更柔和，使用 `dialog` 圆角。侧栏与三维视口的主分区保持直边。

动作图标使用内联 SVG、无填充和当前文本色，常用画布为 24 × 24、描边 1.5，显示尺寸为 16px；视口工具显示为 17px。标志是独立的 1.6 描边，场地按钮图标显示为 24px。增加、关闭、移动与移除动作保持同一套线条，不再以字体符号充当可见图标。

## Components

### Buttons

主要按钮使用操作绿与白字；次要按钮用面板白、墨色文字和细边；安静按钮取消可见底色与边线。悬停只改变背景，禁用状态透明度为 0.45。共用键盘可见焦点规则；动作名称直接说明结果。添加图片按钮额外带 SVG 加号，文本左对齐。

### Inputs / Fields

白底、细线和轻微圆角。常规字段使用 10px 内边距；并列尺寸字段为 9px 7px。标签在字段上方，单位出现在标签附近。聚焦边线为 `#789b86`，柔和外环为 `0 0 0 3px #789b8615`；键盘焦点仍需可见。项目标题与作品名称是融入页面的无底色输入框。

### Navigation

观看方式是一个紧凑的分段按钮组：当前项深绿白字。墙面视图是独立横向条：当前项浅绿底、绿字，窄屏保持横向滚动。这两类状态不能互换，前者选择观看模式，后者定位具体墙面。

### Cards / Containers

作品列表项包含保留原比例的缩略图、名称、尺寸和编号。默认透明，悬停浅灰，选中浅绿并出现细边线。名称过长时省略；图像使用 `object-fit: contain`。空状态以简短步骤说明开始方式，不放装饰大图。

### Dialogs

对话框使用面板底色、扩散阴影与原生 `dialog`。顶部为标题与有可访问名称的 SVG 关闭按钮，底部为动作。尺寸资料沿用这一结构，扩展为平面图、下载入口和分组表格；表头使用浅绿灰底，行间细线区分资料。

### Selection inspector

选中作品后显示编号、可编辑名称、原比例预览、尺寸和位置字段。桌面驻留在右侧，窄屏以覆盖层打开。尺寸、单位、装裱外缘和图片画面的区别依靠相邻说明传达，不仅依靠颜色。

### Feedback

状态栏使用文字加小圆点；短暂通知采用深绿底白字，并使用 `role="status"`。生成文件后保留“保存文件”链接作为下载补充入口。只看副本与可编辑副本在入口、标题和保存状态中明确命名。

## Do's and Don'ts

### Do:

- **Do** 延续作品清单、真实比例视口和参数面板的工作关系。
- **Do** 以直接动作命名按钮，并保持 SVG 图标与可访问名称一致。
- **Do** 保持作品纵横比，在字段附近明确厘米、米和尺寸依据。
- **Do** 在手机保留尺寸资料、方案文件、导出图片与打包分享四个入口。
- **Do** 对只看副本、可编辑副本和本机保存使用明确文字。

### Don't:

- **Don't** 用营销式大标题挤占布展工作区。
- **Don't** 将作品的色彩或三维材质改写成界面装饰色。
- **Don't** 把独立文件副本描述为多人实时同步。
- **Don't** 将遗留的小字号操作、隐藏的符号图标或未使用装饰样式推广为设计规范。
