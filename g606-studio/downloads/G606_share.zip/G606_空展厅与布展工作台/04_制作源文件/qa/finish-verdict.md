## verdict

1. resolved — The recaptured desktop/mobile add controls, room disclosure, and dimension-dialog close control now share the SVG stroke treatment. Source inspection confirms the same 1.5px SVG system for walking arrows, dynamic inspector close, and door/window removal, with action labels and aria-labels retained.
2. resolved — The selected artwork ordinal is visibly larger in qa/desktop-selected.png; the final .inspector-heading rule is 12px. Its alignment remains intact.

## remaining

Clear. All four required recaptures are valid; no regressions introduced by this fix batch are visible. This ship verdict covers the scored fixes, not the whole surface.

disposition: ship
