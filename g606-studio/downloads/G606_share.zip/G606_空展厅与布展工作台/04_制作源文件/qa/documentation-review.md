# G606 documentation review

Date: 2026-11-06

Disposition: documented within the existing-surface extension scope. This is a documentation check, not a new full-surface ship verdict. All paths below are relative to the project root.

## Evidence checked

- Read the incumbent `PRODUCT.md`, `DESIGN.md` and `.impeccable/surface.md`; preserved the empty-gallery purpose, independent ONCE reference and existing editor topology.
- Read final `site/style.css` and `site/index.html`; sampled `site/app.js` for list rendering, local persistence, import/export, sharing modes and dimensions; sampled `site/scene.js` for the actual viewport background, geometry presentation and interaction depth.
- Visually inspected `qa/desktop-1353.png`, `qa/desktop-selected.png`, `qa/mobile-390-final.png` and `qa/mobile-dimensions.png`. The desktop captures are 1353 × 848; mobile captures are 390 × 844. The imported test-art and browser-extension overlay are not part of the empty default or the design system.
- Read `qa/finish-review.md` and `qa/finish-verdict.md`. The final verdict resolves SVG action icons and the 12px selected-work ordinal only. This review does not broaden that verdict.

## Documentation changes

- Merged the original design commitments into `DESIGN.md` using the canonical section order and YAML token frontmatter. Recorded the final cascade, responsive topology, actual UI type roles, SVG treatment, field states and restrained depth.
- Added `.impeccable/design.json` as a schemaVersion 2 extension sidecar: metadata, preview color ramps, observed shadow/motion/breakpoint values and self-contained component snippets. Preview ramps are generated swatches for the documentation panel, not implemented UI tokens or an approved expanded palette.
- Updated `.impeccable/surface.md` with source-defined capabilities and explicit evidence limits. Product truth and scene/model code were not edited.

## Drift not canonized or repaired

- The previous blanket statement that normal text is at least 12px did not describe the final cascade. Reused auxiliary metadata is 11px, while the selected-work ordinal is now 12px. The record distinguishes these roles rather than changing the interface.
- The existing placement button (`#work-placement`), object actions and checkbox labels still use 11px. Their source values are noted here as inherited compact-control drift; they were not promoted into the reusable component scale or changed in this documentation pass. This is outside the two scored finish fixes.
- Unused or hidden legacy styles include the eyebrow selector, the hidden empty-state font glyph and stale conflict/reconnect treatments. They are not part of the documented component examples. The preview block's earlier hard offset shadow is overridden by the final CSS, so it is not an active shadow token.
- CSS reduced-motion support stops transitions; the Three.js camera still uses damping. No global motion-free behavior or new display-font identity is claimed.

## Verification boundary

No live browser workflow, full keyboard or assistive-technology audit, Windows physical-machine test, `file://` offline execution, public-link availability check, PDF re-render, or geometry round-trip was performed by this documentation pass. Source implementation, supplied screenshots, prior test reports and live-runtime verification are separate evidence categories. The core source files and `PRODUCT.md` were hash-checked before and after documentation edits.

Document validation passed: YAML and JSON parse, all token/component references resolve, eight canonical DESIGN.md sections remain in order, nine sidecar components are present, and all recorded source hashes are unchanged. The four written documents contain no local user path. Component snippets were source-checked, not separately browser-rendered.
