disposition: fix

Scope: inherited Operate extension under the parent-supplied “Extend an existing surface” exemption; no new-world FORM seed, comp, or QUALITY BAR card applies. Unread: generated bundle/vendor code, seed/dimension data modules, downloadable artifacts/PDF, and unsampled scene internals. This is a file/capture review; no browser, offline-runtime, or published-link verification was performed.

## persistence

Pass for the extension route. PRODUCT.md, DESIGN.md, and .impeccable/surface.md exist and agree on an empty measured G606 workspace, user artwork import, editable independent copies, and a separately linked ONCE reference. DESIGN.md matches the inherited three-panel editor and green controls. The quoted existing-surface route makes a new concept tournament, comp approval, and FORM seed inapplicable.

Evidence passes: qa/desktop-1353.png and qa/desktop-selected.png are complete 1353 × 848 desktop captures; qa/mobile-390-final.png and qa/mobile-dimensions.png are valid 390 × 844 viewport captures. None is blank or malformed. The black Chatly overlay is excluded as browser-extension UI. The earlier mobile-390.png was not used.

## fidelity

| Element or promise | State | Evidence |
| --- | --- | --- |
| TYPE: inherited tool typography | match | System Chinese sans, restrained heading scale, and tabular dimensions follow DESIGN.md; this is an editor extension with no new display identity. |
| MATERIAL: gallery and artworks | match | The focal scene is actual Three.js geometry with imported artwork textures; no fabricated CSS surface stands in for a promised material. |
| GROUND | match | The final CSS retains the documented paper #f9f8f3, panel #fcfbf8, and inherited pale gray gallery field; the captures show the same treatment. |
| Desktop topology and action order | match | Artwork library, central gallery, and selected-object inspector remain intact; add, dimension, export, and share actions are immediately identifiable. |
| Mobile topology | adaptation | Stacking the gallery above the library preserves the confirmed import-and-curate workflow and the surface brief’s mobile operation requirement; the four header actions remain visible. |
| Empty gallery plus own artwork | match | The supplied captures intentionally contain the separately imported synthetic test-art. qa/geometry-tests.json reports the empty-default check; no claim that this imported test is a seeded user artwork is made. |
| Measurements and model coordinates | match | The dimension dialog identifies original G606 reference data and coordinate axes; app.js translates GLB output to the stated origin. The provided geometry report passes. PDF completeness and Blender round-trip results remain parent-reported evidence. |
| Sharing truth | match | The interface distinguishes editable HTML, viewing HTML, JSON, and independent copies; it makes no multiplayer claim. The parent reports real export/reimport. Actual file:// execution and the pending public download URLs remain unverified. |
| Functional type size | contradicted | The selected-work ordinal above test-art remains 10px through .inspector-heading in site/style.css:1 and is visibly smaller than adjacent functional metadata in desktop-selected.png. |
| Icon system | contradicted | Visible add, disclosure, and close controls still use font glyphs; walking and dynamically created close/remove controls do likewise, alongside the otherwise consistent SVG toolbar. |

## ceiling

No separate new-world card applies. The inherited editor’s native devices—large spatial viewport, restrained green actions, compact numeric fields, and direct geometry—are in use. No additional ornament or authored entrance motion is justified by this extension contract. Finish remains limited by the two floor findings below.

## material_fixes

1. [Floor: icon system] Replace the glyph icons in site/index.html:19,21,24,33 and dialog close controls, plus site/app.js:126,163, with authored SVG using the existing toolbar stroke; preserve their action labels and aria-labels.
2. [Floor: functional type] Raise .inspector-heading / #selected-number from 10px to at least 11px, preferably the documented 12px, so the selected artwork ordinal meets the same legibility floor as the list metadata; verify it in desktop-selected.png.

## keep

Keep the real-proportion gallery, empty default, source-preserving artwork import, explicit centimetres/metres, separately linked ONCE reference, and independent-copy sharing language.
