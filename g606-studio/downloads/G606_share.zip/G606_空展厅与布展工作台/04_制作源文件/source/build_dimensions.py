from pathlib import Path
import json,math,html,csv
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,landscape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle,PageBreak,Spacer
from reportlab.lib.styles import ParagraphStyle
R=Path(__file__).resolve().parents[1];r=json.loads((R/'site/g606-empty.json').read_text())['room'];ds=[]
(R/'dimensions').mkdir(exist_ok=True);(R/'qa').mkdir(exist_ok=True)
def add(group,name,value,status,note):ds.append(dict(group=group,name=name,value=str(value),status=status,note=note))
M='用户实测';D='计算所得';E='照片估计 / 待复测'
for row in [
('总宽，墙1 / 墙3','934',D,'463 + 10 + 461；旧910已经作废'),('进深，墙2 / 墙4','619.5',M,'两侧墙相同；旧538.5已经作废'),('层高','390',M,'原用户确认；灯梁另列'),('中墙两侧净宽：左 / 右','463 / 461',M,'从侧墙面到中间突出墙相应墙面'),('中间墙厚','10',M,'不含柱径'),('中间墙高','250',M,'墙上方至顶约140'),('后墙至柱近面','258',M,'左右与中央柱同一排'),('圆柱直径','58',M,'三柱同径，轴线对齐'),('后墙至柱轴','287',D,'258 + 58÷2'),('墙1至柱轴','332.5',D,'619.5 - 287'),('侧墙柱前净段 / 柱后净段','303.5 / 258',D,'另有58厘米柱身：303.5+58+258=619.5'),('中墙模型轴线长度 / 可见平墙段','287 / 258',D,'矩形墙延伸至柱轴；柱面遮住前端29厘米'),('中墙轴线距墙4 / 墙2','468 / 466',D,'对应463+5、461+5'),('两侧柱之间净距：左 / 右','410 / 408',D,'按模型柱轴相减再减两侧半径；不是消防结论'),('模型地面轮廓面积','57.8613 m²',D,'9.34×6.195，未扣柱墙占地')]:add('主体与柱墙',*row)
for row in [
('左右门洞净宽','90 / 90',M,'门都在墙3两端；左开、右关为用户确认状态'),('门洞高度','210',E,'宽度已测，门高未提供实测'),('左门状态','向左完全开启',M,'门扇贴墙4；右门默认关闭'),('大窗净宽','136.5',M,'墙1左侧唯一完整窗'),('大窗左边距墙4','41.5（模型）',D,'窗台37 + 居中差4.5；早期现场口述41.6，相差0.1'),('大窗下沿 / 上沿','73 / 330',D,'73实测；330为照片估计，实际窗高待复测'),('三个高窗宽度','各136.5',D,'按原窗等宽对齐；现场复测可补'),('高窗下沿','275',D,'窗台73 + 实测上下间隔202'),('高窗上沿 / 模型高度','330 / 55',E,'上沿未实测'),('高窗左边距墙4','280 / 518.5 / 757',D,'对应各窗台中心，模型定位'),('各窗框正面宽 / 凹进','4.5 / 18',E,'照片外观建模，不作为加工依据')]:add('门窗',*row)
for row in [
('四个窗台宽度','各145.5',M,'包含完整窗台与三个封窗留下的白窗台'),('窗台顶离地 / 厚度','73 / 4',M,'下沿离地69'),('窗台之间净距','93',M,'连续三段'),('最左窗台左边距墙4','37',M,'第一个窗台起点'),('最右窗台右边距墙2','35.5（实测） / 36（模型）',M,'窗台链长933.5，对应总宽934，闭合差0.5厘米'),('四窗台左端沿墙1位置','37 / 275.5 / 514 / 752.5',D,'坐标从墙4侧起量'),('白窗台凸出墙面','3.5',E,'未实测，不能据此加工'),('完整窗台模型进深','29',E,'未实测'),('墙1竖向小台阶距墙4','265.5',D,'首个封窗窗台左端275.5 - 用户确认10'),('小台阶凸差','0.8',E,'只表示高差位置；厚度未实测'),('作品跨小台阶','不允许',M,'用户明确要求，位置必须避开')]:add('窗台与不可跨挂接缝',*row)
for row in [
('地砖边长','80',M,'按砖缝中心的网格相位定位'),('砖缝原点O到墙2 / 墙1','132.5 / 80',M,'O在两条砖缝交点'),('O距墙4 / 墙1','801.5 / 80',D,'P为墙1与墙4地面交点，平面坐标(X,Z)=(801.5,80)'),('后门前余砖','58.5（早测） / 59.5（当前推算）',D,'以后来619.5进深为主体；存在1厘米差，请现场对缝'),('电视宽 / 高','91 / 52',M,'默认保留为可选设备，不带VESSEL内容'),('后墙至电视靠门侧边缘','128',M,'沿墙4方向量'),('电视下沿 / 上沿','136 / 188',D,'136实测，188=136+52'),('电视中心距后墙','173.5',D,'128+91÷2'),('黑踢脚线高 / 厚','10 / 1.4',E,'按照片建模'),('梁底离地','340',E,'模型按顶390减梁高50'),('横梁宽 / 高','40 / 50',E,'中柱排横梁'),('纵梁宽 / 高','36 / 50',E,'中墙上方纵梁'),('周边梁宽 / 高','28 / 50',E,'周边连续梁'),('吊灯长 / 宽 / 下沿','120 / 24 / 310',E,'6组灯与吊杆仅作外观；现场核定'),('开关位置沿墙3','186.5 / 734.5',E,'起点为墙3右端；高度125，按照片估计'),('管线位置沿墙3','488.3 / 498',E,'直径3.4，按照片估计')]:add('地砖、电视与上部设施',*row)
# Exact coordinate diagram: wall1 at the top, entrances at bottom. Not a north arrow.
svg=[]
def S(t):svg.append(t)
def line(x1,y1,x2,y2,c='#566359',w=1,dash=''):
 S(f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="{c}" stroke-width="{w}" '+(f'stroke-dasharray="{dash}"' if dash else '')+'/>')
def text(t,x,y,size=15,anchor='middle',color='#263a2f'):
 S(f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" text-anchor="{anchor}" fill="{color}">{html.escape(str(t))}</text>')
def rect(x,y,w,h,fill,stroke='#54675b',sw=1):S(f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h:.2f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
def dim(x1,y1,x2,y2,label,vertical=False):
 line(x1,y1,x2,y2);d=5
 if vertical:line(x1-d,y1,x1+d,y1);line(x2-d,y2,x2+d,y2);text(label,x1+12,(y1+y2)/2,14,'start')
 else:line(x1,y1-d,x1,y1+d);line(x2,y2-d,x2,y2+d);text(label,(x1+x2)/2,y1-9,14)
s=.9;ox=120;oy=138;xx=lambda v:ox+v*s;yy=lambda v:oy+v*s
S('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1120 880" role="img" aria-label="G606带尺寸平面图" font-family="Arial Unicode MS, PingFang SC, Microsoft YaHei, sans-serif">')
rect(0,0,1120,880,'#fafaf6','none');text('G606 · 实测平面与定位基准',55,45,24,'start');text('厘米 / 比例示意；P为坐标原点，图上方为墙1，不代表地理北向',55,73,14,'start', '#58675d')
rect(xx(0),yy(0),934*s,619.5*s,'#f0f0e9')
for v in [801.5-80*n for n in range(11)]:
 if v>0:line(xx(v),yy(0),xx(v),yy(619.5),'#d0d6cd',.65)
for v in range(80,620,80):line(xx(0),yy(v),xx(934),yy(v),'#d0d6cd',.65)
# walls and doors
a=0
for p,q in [((0,0),(934,0)),((934,0),(934,619.5)),((844,619.5),(90,619.5)),((0,619.5),(0,0))]:line(xx(p[0]),yy(p[1]),xx(q[0]),yy(q[1]),'#273d30',5)
# partition and columns
rect(xx(463),yy(332.5),10*s,287*s,'#53665a')
for x in [0,468,934]:S(f'<circle cx="{xx(x)}" cy="{yy(332.5)}" r="{29*s}" fill="#c4cec2" stroke="#294532" stroke-width="2"/>')
# wide window + high windows / sills
for i,start in enumerate([37,275.5,514,752.5]):
 rect(xx(start),yy(0)+4,145.5*s,8,'#b8c8c5')
 line(xx(start+4.5),yy(0),xx(start+141),yy(0),'#9cbbc1',5)
 text('完整窗' if not i else f'高窗{i}',xx(start+72.75),yy(0)+34,14)
# seam, television, doors, O
line(xx(265.5),yy(-8),xx(265.5),yy(38),'#b06e41',2,'4 3');text('接缝265.5',xx(265.5),yy(63),13)
rect(xx(0)+5,yy(400.5),10,91*s,'#56676c');text('电视',xx(30),yy(445),14,'start')
line(xx(0)+5,yy(619.5),xx(0)+5,yy(529.5),'#9f815d',4)
line(xx(844),yy(619.5),xx(934),yy(619.5),'#9f815d',4)
text('左入口 · 开门靠墙4',xx(100),yy(619.5)+29,14);text('右门 · 默认关闭',xx(843),yy(619.5)+29,14)
text('墙1  →',xx(467),yy(0)-20,17);text('墙3  ←',xx(467),yy(619.5)+31,17)
text('墙4',xx(0)-65,yy(180),17);text('墙2',xx(934)+65,yy(180),17)
text('中墙右面',xx(535),yy(498),14);text('中墙左面',xx(400),yy(498),14)
S(f'<circle cx="{xx(801.5)}" cy="{yy(80)}" r="5" fill="#3b7358"/>');text('O',xx(801.5)+13,yy(80)-8,16,'start')
text('P (0,0)',xx(0)-10,yy(0)-10,13,'end')
dim(xx(0),100,xx(934),100,'934')
dim(xx(0),yy(525),xx(463),yy(525),'净463')
dim(xx(473),yy(525),xx(934),yy(525),'净461')
dim(50,yy(0),50,yy(619.5),'619.5',True)
dim(1022,yy(0),1022,yy(303.5),'303.5',True)
dim(1022,yy(303.5),1022,yy(361.5),'Ø58',True)
dim(1022,yy(361.5),1022,yy(619.5),'258',True)
dim(xx(801.5),yy(112),xx(934),yy(112),'132.5')
text('地砖80×80；O距墙1为80',xx(730),yy(210),14)
text('中墙厚10 / 高250；其余层高390',xx(330),yy(430),15)
text('每条墙的箭头表示工作台“中心距墙起点”的正方向。墙2向下，墙4向上。',55,790,15,'start')
text('尺寸依据：用户实测2026-10-23 / 网页场地v117。窗顶、灯梁与凸出厚度须复测。',55,820,14,'start')
text('侧墙测量链：303.5 + 58 + 258 = 619.5；中间墙与圆柱分别保留。',55,845,14,'start')
S('</svg>');plan=''.join(svg)
(R/'dimensions/G606_实测平面.svg').write_text(plan)
(R/'site/dimensions.js').write_text('export const DIMENSIONS='+json.dumps(ds,ensure_ascii=False)+';\nexport const PLAN_SVG='+json.dumps(plan,ensure_ascii=False)+';\n')
(R/'dimensions/G606_尺寸依据.json').write_text(json.dumps({'sourceRevision':117,'surveyDate':'2026-10-23','coordinateOrigin':'wall1-wall4 floor corner','coordinateAxes':'X right; Y up; Z toward wall3','records':ds},ensure_ascii=False,indent=2)+'\n')
with (R/'dimensions/G606_完整尺寸表.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['分组','部位','尺寸（厘米）','依据','说明']);w.writerows([d[k] for k in ['group','name','value','status','note']] for d in ds)
# PDF uses embedded Chinese type and vector geometry; diagram positions reuse the SVG.
pdfmetrics.registerFont(TTFont('Unicode','/System/Library/Fonts/Supplemental/Arial Unicode.ttf'))
import sys
import io
sys.path.insert(0,str(R/'.tools/pylibs'))
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
W,H=landscape(A4)
class DrawingFlow:
 pass
from reportlab.platypus import Flowable
class Diagram(Flowable):
 def __init__(self):Flowable.__init__(self);self.width=760;self.height=460
 def draw(self):
  source=plan.replace('Arial Unicode MS, PingFang SC, Microsoft YaHei, sans-serif','Unicode')
  dr=svg2rlg(io.BytesIO(source.encode()))
  def fontfix(node):
   if hasattr(node,'fontName'):node.fontName='Unicode'
   for child in getattr(node,'contents',[]):fontfix(child)
  fontfix(dr);scale=min(self.width/dr.width,self.height/dr.height);dr.scale(scale,scale);renderPDF.draw(dr,self.canv,25,0)
class Elevation(Flowable):
 def __init__(self,wall):Flowable.__init__(self);self.wall=wall;self.width=750;self.height=400
 def draw(self):
  c=self.canv;i=self.wall;length=[934,619.5,934,619.5,287,287][i];height=390 if i<4 else 250
  scale=min(650/length,260/390);x0=48;y0=75
  def box(x,y,w,h,fill='#f6f6f1',stroke='#596b5e'):
   c.setFillColor(colors.HexColor(fill));c.setStrokeColor(colors.HexColor(stroke));c.setLineWidth(.6);c.rect(x0+x*scale,y0+y*scale,w*scale,h*scale,fill=1)
  def txt(s,x,y,size=10,align='center'):
   c.setFont('Unicode',size);c.setFillColor(colors.HexColor('#263a2f'));getattr(c,{'center':'drawCentredString','left':'drawString','right':'drawRightString'}[align])(x,y,s)
  def dim(x,y,w,label):
   c.setStrokeColor(colors.HexColor('#7b897e'));c.setLineWidth(.5);c.line(x0+x*scale,y,x0+(x+w)*scale,y)
   for t in [x,x+w]:c.line(x0+t*scale,y-3,x0+t*scale,y+3)
   txt(label,x0+(x+w/2)*scale,y+6,9)
  box(0,0,length,height)
  c.setStrokeColor(colors.HexColor('#7b897e'));c.setLineWidth(.5)
  hx=x0-20;c.line(hx,y0,hx,y0+height*scale)
  for hy in [y0,y0+height*scale]:c.line(hx-3,hy,hx+3,hy)
  txt(str(height),hx-6,y0+height*scale/2,9,'right')
  if i<4:
   for o in r['openings']:
    if o['wall']!=i:continue
    x,y,w,h=[o[k]*100 for k in ['start','bottom','width','height']];box(x,y,w,h,'#dfe9e7' if o['type']=='window' else '#ede5d7')
    txt('窗' if o['type']=='window' else '门',x0+(x+w/2)*scale,y0+(y+h/2)*scale,9)
  if i==0:
   for k,start in enumerate([37,275.5,514,752.5]):
    box(start,69,145.5,4,'#bacabe');dim(start,y0-24,145.5,'145.5')
   seam=x0+265.5*scale;c.setStrokeColor(colors.HexColor('#a46b41'));c.setDash(3,2);c.line(seam,y0,seam,y0+height*scale);c.setDash()
   txt('接缝 265.5 · 不跨挂',seam,y0+height*scale+34,9);dim(0,y0-47,265.5,'从墙4量 265.5')
   txt('窗台顶 73 / 高窗下沿 275 / 窗顶 330（估计）',x0,y0-69,10,'left')
  if i in [1,3]:
   center=332.5 if i==1 else 287
   box(center-29,0,58,390,'#c8d2c7');txt('柱 Ø58',x0+center*scale,y0+height*scale+14,10)
   if i==3:
    box(128,136,91,52,'#465457');txt('电视91×52',x0+173.5*scale,y0+210*scale,10);dim(0,y0-24,128,'128')
    txt('电视下沿136；左门打开后靠墙4，门高210为估计',x0,y0-55,10,'left')
   left=center-29;dim(0,y0-42,left,str(left));dim(center+29,y0-42,length-center-29,str(length-center-29))
  if i==2:
   box(461,0,10,250,'#c8d2c7');txt('中墙与后墙交接',x0+466*scale,y0+270*scale,10)
   dim(0,y0-24,90,'90');dim(844,y0-24,90,'90');txt('面对墙3：左侧为默认关闭的右门；右侧为打开的左入口',x0,y0-55,10,'left')
  if i>=4:
   colx=258 if i==4 else 0;box(colx,0,29,390,'#c8d2c7');txt('圆柱遮住墙端29',x0+(272.5 if i==4 else 14.5)*scale,y0+390*scale+13,9)
   dim(0 if i==4 else 29,y0-24,258,'可见平墙 258');txt('平墙高250；圆柱至层顶390。两面墙坐标起点相反。',x0,y0-55,10,'left')
  dim(0,y0+height*scale+20,length,str(length))
  txt('起点 0 →',x0,y0-7,9,'left');txt('地面 ±0',x0+length*scale+8,y0,9,'left')
body=ParagraphStyle('body',fontName='Unicode',fontSize=9,leading=14,textColor=colors.HexColor('#263a2f'))
heading=ParagraphStyle('head',parent=body,fontSize=21,leading=29,spaceAfter=14)
sub=ParagraphStyle('sub',parent=body,fontSize=13,leading=19,spaceBefore=12,spaceAfter=9)
story=[Diagram(),PageBreak()]
for i,name in enumerate(['墙1 · 窗与接缝','墙2 · 右侧墙','墙3 · 门所在墙','墙4 · 左侧墙与电视','中墙右侧','中墙左侧']):
 story += [Paragraph('G606 · '+name,heading),Paragraph('从室内正对该墙观看；厘米。图面左端为工作台该墙坐标起点。门窗的估计项见尺寸表。',body),Spacer(1,12),Elevation(i),PageBreak()]
story += [Paragraph('G606 · 全部尺寸与依据',heading),Paragraph('主体采用2026年10月23日实测修订，模型v117。尺寸单位为厘米，面积单独标注。三维文件使用米制；平面P原点在墙1与墙4的地面交点。',body),Spacer(1,12)]
for group in dict.fromkeys(d['group'] for d in ds):
 story.append(Paragraph(group,sub));rows=[[Paragraph(x,body) for x in ['部位','尺寸 / cm','依据','说明']]]
 for d in [d for d in ds if d['group']==group]:rows.append([Paragraph(html.escape(d[k]),body) for k in ['name','value','status','note']])
 t=Table(rows,colWidths=[170,150,100,330],repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e2e9df')),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#788777')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d7ded4')),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]));story.append(t)
 # One section per page keeps dense evidence usable during measuring.
 story.append(PageBreak())
story += [Paragraph('坐标与交接说明',heading),Paragraph('GLB：X向右，Y向上，Z从墙1向墙3。Blender导入会转换为Z向上；保持1单位=1米。空展厅模型包含门窗、柱墙、窗台、梁灯及电视，不包含上一场作品、前言、地诗或临时桌椅。',body),Spacer(1,12),Paragraph('墙面定位起点',sub),Paragraph('墙1：左到右；墙2：墙1端到后墙；墙3：右到左；墙4：后墙到墙1。中墙右面：后墙到柱轴；中墙左面：柱轴到后墙。工作台“中心距墙起点”沿这个方向量，底边离地指作品或装裱的外缘。',body),Paragraph('尚需现场复测',sub),Paragraph('窗顶与门高、所有灯梁尺寸和悬挂标高、接缝凸差、窗台凸出深度、踢脚线、开关及管线。尺寸链存在窗台0.5厘米、后门余砖1厘米的闭合差，已明确列出；不要把旧估计9.10米宽、5.385米深重新用于布展。墙1小台阶位置需避开。',body),Paragraph('本包的用途',sub),Paragraph('用于策展讨论、真实比例排布和跨电脑交接。现场安装固定、顶部承重、玻璃或新增隔墙等须按实际场地条件确定。原ONCE展览以独立网页链接保留作参考。朋友的作品可导入工作台，导出带图HTML或JSON再分享。',body)]
def footer(c,doc):
 c.setFont('Unicode',8);c.setFillColor(colors.HexColor('#5a685d'));c.drawString(35,20,'G606 空间分享资料 / 2026-11-06 / v117 geometry');c.drawRightString(W-35,20,str(doc.page))
doc=SimpleDocTemplate(str(R/'dimensions/G606_完整尺寸与平面.pdf'),pagesize=(W,H),leftMargin=40,rightMargin=40,topMargin=30,bottomMargin=35);doc.build(story,onFirstPage=footer,onLaterPages=footer)
import fitz
pdf=fitz.open(R/'dimensions/G606_完整尺寸与平面.pdf');pages=[]
for i,page in enumerate(pdf):
 out=R/'qa'/f'dimensions-page-{i+1:02}.png';page.get_pixmap(matrix=fitz.Matrix(1.2,1.2),alpha=False).save(out);pages.append(str(out))
print(json.dumps({'records':len(ds),'pdfPages':len(pdf),'preview':pages},ensure_ascii=False))
