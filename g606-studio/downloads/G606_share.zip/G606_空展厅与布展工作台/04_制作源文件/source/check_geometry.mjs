import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../site/vendor/three.module.js';
import {ExhibitionScene} from '../site/scene.js';
import {INITIAL_STATE} from '../site/seed.js';
import {validateState,bounds,walls,wallPosition,workBounds,resizeArtwork,canWalk,normalizeOutline} from '../site/model.js';

const state=validateState(INITIAL_STATE),b=bounds(state.room),ws=walls(state.room);
const near=(a,e)=>assert.ok(Math.abs(a-e)<1e-6,`${a} != ${e}`);
near(b.width,9.34);near(b.depth,6.195);near(state.room.height,3.9);
assert.equal(state.works.length,0);assert.equal(ws.length,6);
near(ws[4].length,2.87);near(ws[4].height,2.5);
near(ws[5].a[0]-b.minX,4.63);near(b.maxX-ws[4].a[0],4.61);
assert.equal(state.room.columns.length,3);
for(const c of state.room.columns){near(c.z-b.minZ,3.325);near(c.diameter,.58);assert.equal(canWalk(state.room,c.x,c.z),false);}
const w={id:'qa',type:'art',name:'test',width:.6,height:.4,depth:.02,x:0,z:0,rotation:0,wall:0,along:4,elevation:1.1,frame:'black',frameWidth:.008,mat:.04};
wallPosition(w,state.room);near(w.x-b.minX,4);near(w.elevation,1.1);near(workBounds(w).width,.696);
resizeArtwork(w,'width',1.2);near(w.height,.8);near(workBounds(w).width,1.296);
validateState({...state,works:[w]});
assert.throws(()=>validateState({...state,works:[{...w,image:'https://bad.invalid/a.png'}]}));
assert.throws(()=>normalizeOutline([[0,0],[3,3],[0,3],[3,0]]));
assert.throws(()=>validateState({...state,room:{...state.room,tileSize:0}}));
assert.throws(()=>validateState({...state,room:{...state.room,columns:[{x:0,z:0,diameter:null}]}}));
const frames=[];
for(const [width,height] of [[390,480],[390,640],[831,849],[918,760],[1440,900]]){
 const o=Object.create(ExhibitionScene.prototype);
 Object.assign(o,{state,mode:'overview',element:{clientWidth:width,clientHeight:height},navigation:new Set(),perspective:new THREE.PerspectiveCamera(42,width/height,.01,500),orthographic:new THREE.OrthographicCamera(),renderer:{setSize(){}},applyVisibility(){},controls:{target:new THREE.Vector3(),mouseButtons:{},update(){this.object.lookAt(this.target);this.object.updateMatrixWorld();}}});
 o.view('overview');o.camera.updateMatrixWorld();let mx=0,my=0;
 for(const x of [b.minX,b.maxX])for(const z of [b.minZ,b.maxZ])for(const y of [0,state.room.height]){
  const p=new THREE.Vector3(x,y,z).project(o.camera);mx=Math.max(mx,Math.abs(p.x));my=Math.max(my,Math.abs(p.y));
 }
 assert.ok(mx<1&&my<1,`overview clips at ${width}x${height}: ${mx},${my}`);
 frames.push({width,height,maxNdcX:mx,maxNdcY:my});
}
const result={passed:true,checks:['current measured geometry','empty default','column collision','wall coordinate placement','mat and frame dimensions','aspect resize','unsafe image URL rejected','self-crossed outline rejected','overview projection at five sizes'],frames};
fs.writeFileSync('qa/geometry-tests.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
