from pathlib import Path
import bpy,math,json
from mathutils import Vector,Quaternion
R=Path(__file__).resolve().parents[1]
(R/'models').mkdir(exist_ok=True);(R/'qa').mkdir(exist_ok=True)
model=R/'models/G606_空展厅_米制.glb'
if not model.exists():model=R.parent/'01_空展厅模型/G606_空展厅_米制.glb'
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(model))
s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
collections={}
for name in ['01_墙体与门窗','02_地面与柱','03_顶部灯梁_显示可开启','04_布展作品_当前为空','05_预览相机灯光']:
 c=bpy.data.collections.new(name);s.collection.children.link(c);collections[name]=c
qa={'unit':'m','coordinateNote':'Blender X right, Y toward wall1 (negative toward wall3), Z up. Origin wall1-wall4 floor corner.','columns':[],'displayHidden':[],'source':'GLB exported from app with full architecture'}
for obj in list(s.objects):
 category='01_墙体与门窗'
 if obj.name.startswith('Curatorial_Layout'):category='04_布展作品_当前为空'
 elif obj.get('ceilingSurface') or obj.get('ceilingFixture') or obj.get('overheadStructure'):category='03_顶部灯梁_显示可开启'
 elif obj.name.startswith('Column_') or (obj.type=='MESH' and not obj.get('wallIndex') and obj.dimensions.z<.1):category='02_地面与柱'
 for col in list(obj.users_collection):col.objects.unlink(obj)
 collections[category].objects.link(obj)
 if obj.name.startswith('Column_'):
  bpy.context.view_layer.update();qa['columns'].append({'name':obj.name,'position':list(obj.matrix_world.translation),'dimensions':list(obj.dimensions)})
 # Keep every mesh in the file. The default saved view is a cutaway like the workbench.
 if category=='03_顶部灯梁_显示可开启' or obj.get('wallIndex') in [1,2]:
  obj.hide_set(True);obj.hide_render=True;qa['displayHidden'].append(obj.name)
# Context annotation travels with the editable file.
t=bpy.data.texts.new('先读我_G606.txt');t.write('G606 空展厅，1单位=1米。完整建筑已保留。\n默认预览隐藏墙2、墙3和顶部，以便看到室内；Alt+H 恢复全部物体，渲染显示可在对象属性恢复。\n主体尺寸934×619.5厘米，层高390厘米，中墙高250厘米。\n门高、窗顶、灯梁、凸出厚度来自照片估计，请同时查看完整尺寸PDF。\n此文件无摄影作品、地诗、前言或临时家具。电视作为现场设备保留。')
# glTF line primitives import as loose edges in Blender. Give the measured tile
# seams a very thin curve so the saved native model retains a visible grid.
seams=bpy.data.curves.new('80厘米地砖缝','CURVE');seams.dimensions='3D';seams.bevel_depth=.0015;seams.bevel_resolution=0
for x in [8.015-.8*n for n in range(11)]:
 if 0<x<9.34:
  sp=seams.splines.new('POLY');sp.points.add(1);sp.points[0].co=(x,0,.001,1);sp.points[1].co=(x,-6.195,.001,1)
for y in [.8*n for n in range(1,8)]:
 sp=seams.splines.new('POLY');sp.points.add(1);sp.points[0].co=(0,-y,.001,1);sp.points[1].co=(9.34,-y,.001,1)
seamobj=bpy.data.objects.new('Tile_Seams_80cm',seams);collections['02_地面与柱'].objects.link(seamobj)
mat=bpy.data.materials.new('地砖缝');mat.diffuse_color=(.37,.39,.35,1);seams.materials.append(mat)
bpy.ops.object.camera_add(location=(15,-15,12));cam=bpy.context.object;cam.name='G606_空间总览';direction=Vector((4.67,-3.1,1.35))-cam.location;cam.rotation_euler=direction.to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=14;s.camera=cam
for col in list(cam.users_collection):col.objects.unlink(cam)
collections['05_预览相机灯光'].objects.link(cam)
for location,energy,size in [((4.7,-3,11),1400,10),((-4,-1,7),1100,8),((10,-8,7),1000,8)]:
 bpy.ops.object.light_add(type='AREA',location=location);o=bpy.context.object;o.data.energy=energy;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((4.6,-3.1,0))-o.location).to_track_quat('-Z','Y').to_euler()
 for col in list(o.users_collection):col.objects.unlink(o)
 collections['05_预览相机灯光'].objects.link(o)
s.world=bpy.data.worlds.new('White gallery');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.8,.8,.8,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.7
s.render.engine='CYCLES';s.cycles.samples=24;s.render.resolution_x=1600;s.render.resolution_y=1050;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.filepath=str(R/'models/G606_空展厅预览.png');s.view_settings.view_transform='Standard'
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   reg=area.spaces.active.region_3d;reg.view_distance=16;reg.view_location=(4.67,-3.1,1.3);reg.view_rotation=cam.rotation_euler.to_quaternion();area.spaces.active.clip_end=500
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=str(R/'models/G606_空展厅_米制.blend'))
(R/'qa/blender-import-check.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
bpy.ops.render.render(write_still=True)
