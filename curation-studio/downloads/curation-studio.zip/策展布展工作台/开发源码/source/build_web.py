from pathlib import Path
import subprocess,shutil,re,os
R=Path(__file__).resolve().parents[1]
esbuild=os.environ.get('ESBUILD') or str(R/'.tools/esbuild')
if not Path(esbuild).exists():
 esbuild=shutil.which('esbuild')
if not esbuild:raise SystemExit('Install esbuild from npm or set ESBUILD to its executable path.')
subprocess.run([esbuild,'site/app.js','--bundle','--format=iife','--platform=browser','--target=es2020','--alias:three=./site/vendor/three.module.js','--outfile=site/app.bundle.js','--minify','--legal-comments=linked'],cwd=R,check=True)
s=(R/'site/index.html').read_text()
s=re.sub(r'<link rel="stylesheet"[^>]*data-app-style>',lambda m:'<style>'+(R/'site/style.css').read_text()+'</style>',s)
code=(R/'site/app.bundle.js').read_text().replace('</script','<\\/script')
s=re.sub(r'<script id="app-bundle" src="[^"]+" defer></script>',lambda m:'<script id="app-bundle">'+code+'</script>',s)
(R/'双击打开_策展布展工作台.html').write_text(s)
print('Single-file HTML:',len(s.encode()),'bytes')
