from pathlib import Path
import json,html,os
R=Path(__file__).resolve().parents[1]
BASE='https://13864768492jxy-create.github.io/once-exhibition-viewer/curation-studio/'
chapters=json.loads((R/'source/manual-content.json').read_text())
E=html.escape
intro='<p class="manual-intro">用自己的尺寸搭建场地，再把作品放进去。按下列顺序完成一次从建模到分享的布展。制作者 姜昕宇。</p>'
links=f'<div class="manual-links"><a href="{BASE}downloads/curation-manual.pdf" target="_blank" rel="noopener">下载图解说明书 PDF</a><a href="{BASE}?mode=view" target="_blank" rel="noopener">只读观看入口</a><a href="{BASE}downloads/curation-studio.zip" download>下载完整工作台</a></div>'
toc='<nav aria-label="说明书目录"><ol class="manual-toc">'+''.join(f'<li><a href="#guide-{c["id"]}">{i+1:02d}　{E(c["title"])}</a></li>' for i,c in enumerate(chapters))+'</ol></nav>'
def body(c,i,images=False):
 out=f'<section id="guide-{c["id"]}"><h3>{i+1:02d}　{E(c["title"])}</h3>'
 if c.get('intro'):out+='<p>'+E(c['intro'])+'</p>'
 if c.get('steps'):out+='<ol>'+''.join('<li>'+E(s)+'</li>' for s in c['steps'])+'</ol>'
 if c.get('table'):
  out+='<table><thead><tr>'+''.join('<th>'+E(s)+'</th>' for s in c['table'][0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+E(s)+'</td>' for s in row)+'</tr>' for row in c['table'][1:])+'</tbody></table>'
 if images and c.get('image') and (R/'site/guide-images'/c['image']).exists():out+=f'<figure><img src="./guide-images/{c["image"]}" alt="{E(c["title"])}实际操作画面"><figcaption>{E(c["title"])} · 实际工作台界面</figcaption></figure>'
 if c.get('note'):out+='<p class="note">'+E(c['note'])+'</p>'
 return out+'</section>'
footer='<footer>策展布展工作台 · 制作者 姜昕宇<br>版本 1.0 · 2026 年 11 月<br>方案保存在本机；分享的是独立副本。</footer>'
content='<article class="manual-content">'+intro+links+toc+''.join(body(c,i) for i,c in enumerate(chapters))+footer+'</article>'
(R/'site/manual.js').write_text('export const MANUAL_HTML='+json.dumps(content,ensure_ascii=False)+';\n')
full='<article class="manual-content">'+intro+links+toc+''.join(body(c,i,True) for i,c in enumerate(chapters))+footer+'</article>'
(R/'site/manual.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>使用说明书 · 策展布展工作台 · 制作者 姜昕宇</title><link rel="stylesheet" href="./style.css"><main class="manual-page"><header><a class="back-link" href="./">返回工作台</a><h1>策展布展工作台<br>使用说明书</h1></header>'+full+'</main></html>')
# The PDF uses the same text as the in-app manual.
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,KeepTogether
from reportlab.lib.styles import ParagraphStyle
font_path=os.environ.get('CURATION_PDF_FONT','/System/Library/Fonts/Supplemental/Arial Unicode.ttf')
if not Path(font_path).is_file():raise SystemExit('Set CURATION_PDF_FONT to a static Chinese TrueType font file; the supplied PDF needs no rebuild.')
pdfmetrics.registerFont(TTFont('ZH',font_path))
W,H=A4; PW=W-88
styles={k:ParagraphStyle(k,fontName='ZH',fontSize=size,leading=leading,textColor=colors.HexColor('#25392f'),wordWrap='CJK',spaceAfter=space) for k,size,leading,space in [('h1',27,38,22),('h2',19,28,18),('body',10.5,17,10),('small',9,14,8),('table',9.5,15,0)]}
def p(s,k='body'):return Paragraph(E(s).replace('\n','<br/>'),styles[k])
def page(c,doc):
 c.setStrokeColor(colors.HexColor('#d6dad2'));c.line(44,35,W-44,35);c.setFont('ZH',8);c.setFillColor(colors.HexColor('#58675d'));c.drawString(44,22,'策展布展工作台  /  制作者 姜昕宇');c.drawRightString(W-44,22,f'{doc.page:02d}')
story=[Spacer(1,45),p('策展布展工作台\n使用说明书','h1'),p('从自己的场地开始，完成一份可观看、可编辑、可交接的展览方案。'),Spacer(1,15),p('制作者 姜昕宇'),p('版本 1.0  /  2026 年 11 月','small'),Spacer(1,24)]
for i,c in enumerate(chapters):story.append(p(f'{i+1:02d}  {c["title"]}','small'))
story.extend([Spacer(1,22),p('在线工作台','small'),Paragraph(f'<link href="{BASE}" color="#355a46">{BASE}</link>',styles['small']),PageBreak()])
for i,c in enumerate(chapters):
 story.append(p(f'{i+1:02d}  {c["title"]}','h2'))
 if c.get('intro'):story.append(p(c['intro']))
 for n,s in enumerate(c.get('steps',[])):story.append(p(f'{n+1}. {s}'))
 if c.get('table'):
  rows=[[p(s,'table') for s in row] for row in c['table']];cols=[PW*.28,PW*.72] if len(rows[0])==2 else [PW/len(rows[0])]*len(rows[0]);t=Table(rows,colWidths=cols,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eee7')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.5,colors.HexColor('#d6dad2'))]));story.extend([Spacer(1,7),t,Spacer(1,12)])
 if c.get('note'):story.append(p(c['note'],'small'))
 if c.get('image') and (R/'site/guide-images'/c['image']).exists():
  from PIL import Image as PILImage
  path=R/'site/guide-images'/c['image'];iw,ih=PILImage.open(path).size;scale=min(PW/iw,250/ih)
  story.extend([Spacer(1,15),Image(str(path),width=iw*scale,height=ih*scale,hAlign='LEFT'),Spacer(1,5),p('实际操作画面；仅作为使用步骤示例，不预置在空白工作台中。','small')])
 if i<len(chapters)-1:story.append(PageBreak())
(R/'site/downloads').mkdir(exist_ok=True)
SimpleDocTemplate(str(R/'site/downloads/curation-manual.pdf'),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=42,bottomMargin=50,title='策展布展工作台 使用说明书',author='制作者 姜昕宇').build(story,onFirstPage=page,onLaterPages=page)
print('Manual chapters',len(chapters))
