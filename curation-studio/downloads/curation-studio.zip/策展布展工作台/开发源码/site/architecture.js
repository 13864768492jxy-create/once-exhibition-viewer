import {clone,normalizeOutline,walls,contains,cm} from './model.js';
export function area(room){return Math.abs(room.points.reduce((s,p,i)=>{const q=room.points[(i+1)%room.points.length];return s+p[0]*q[1]-q[0]*p[1];},0))/2;}
export function onSite(room,x,z){if(contains(room,x,z))return true;return room.points.some((a,i)=>{const b=room.points[(i+1)%room.points.length],dx=b[0]-a[0],dz=b[1]-a[1],t=((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz);return t>=0&&t<=1&&Math.hypot(x-a[0]-dx*t,z-a[1]-dz*t)<.001;});}
export function validateArchitecture(room){
 const r=clone(room);r.points=normalizeOutline(r.points);
 if(!Number.isFinite(r.height)||r.height<1||r.height>30)throw Error('墙高请填 100–3000 厘米。');
 if(!Array.isArray(r.openings)||r.openings.length>60)throw Error('门窗最多 60 处。');
 if(!Array.isArray(r.interiorWalls)||r.interiorWalls.length>40)throw Error('内部展墙最多 40 片。');
 if(!Array.isArray(r.columns)||r.columns.length>100)throw Error('柱子最多 100 根。');
 const ws=walls(r);
 for(const o of r.openings){
  if(!['door','window'].includes(o.type)||!Number.isInteger(o.wall)||o.wall<0||o.wall>=r.points.length)throw Error('请选择门窗所在的外围墙。');
  if(![o.start,o.width,o.height,o.bottom].every(Number.isFinite)||o.start<0||o.width<.1||o.height<.1||o.bottom<0||o.start+o.width>ws[o.wall].length+.001||o.bottom+o.height>r.height+.001)throw Error(`墙 ${o.wall+1} 的门窗超出墙面，请检查起点、宽、高和离地。`);
 }
 for(let i=0;i<r.openings.length;i++)for(let j=i+1;j<r.openings.length;j++){const a=r.openings[i],b=r.openings[j];if(a.wall===b.wall&&a.start<b.start+b.width-.001&&a.start+a.width>b.start+.001&&a.bottom<b.bottom+b.height-.001&&a.bottom+a.height>b.bottom+.001)throw Error('同一墙上的门窗发生重叠，请调整。');}
 for(const w of r.interiorWalls){
  if(!Array.isArray(w.a)||!Array.isArray(w.b)||![...w.a,...w.b,w.height,w.thickness].every(Number.isFinite)||w.a.length!==2||w.b.length!==2||w.height<1||w.height>r.height||w.thickness<.01||w.thickness>2)throw Error('展墙端点、墙高或厚度无效；展墙不能高于场地。');
  const length=Math.hypot(w.a[0]-w.b[0],w.a[1]-w.b[1]);if(length<.1)throw Error('内部展墙至少长 10 厘米。');
  for(let n=0;n<=100;n++)if(!onSite(r,w.a[0]+(w.b[0]-w.a[0])*n/100,w.a[1]+(w.b[1]-w.a[1])*n/100))throw Error('内部展墙超出场地轮廓，请调整端点。');
 }
 for(const c of r.columns){
  if(![c.x,c.z,c.height].every(Number.isFinite)||c.height<.1||c.height>r.height||!onSite(r,c.x,c.z))throw Error('柱子中心须在场地内，高度不能超过墙高。');
  if(c.shape==='box'){if(![c.width,c.depth].every(v=>Number.isFinite(v)&&v>=.05&&v<=10))throw Error('方柱宽、深须在 5–1000 厘米之间。');c.diameter=Math.max(c.width,c.depth);}
  else if(!Number.isFinite(c.diameter)||c.diameter<.05||c.diameter>10)throw Error('圆柱直径须在 5–1000 厘米之间。');
 }
 for(const key of ['wallColor','floorColor'])if(!/^#[0-9a-f]{6}$/i.test(r[key]||''))throw Error('请选择有效的墙面与地面颜色。');
 if(r.tileSize!==undefined&&(!Number.isFinite(r.tileSize)||r.tileSize<.1||r.tileSize>5))throw Error('地砖边长须在 10–500 厘米之间。');
 return r;
}
export function reconcileWorks(oldRoom,newRoom,works){
 const previous=walls(oldRoom),next=walls(newRoom);let returned=0;
 const key=(w,r)=>w.perimeter?`edge:${w.index}`:`inner:${r.interiorWalls[w.innerIndex].id||w.innerIndex}:${(w.index-r.points.length)%2}`;
 const lookup=new Map(next.map(w=>[key(w,newRoom),w.index]));
 const result=works.map(w=>{const c=clone(w);if(c.type!=='art')return c;const old=previous[c.wall];let target=old?lookup.get(key(old,oldRoom)):undefined;
  if(old?.perimeter&&oldRoom.points.length!==newRoom.points.length)target=next.find(n=>n.perimeter&&JSON.stringify(n.a)===JSON.stringify(old.a)&&JSON.stringify(n.b)===JSON.stringify(old.b))?.index;
  if(target===undefined){c.wall=0;c.placed=false;returned++;}else c.wall=target;return c;
 });return {works:result,returned};
}
export function dimensionRows(state){const r=state.room;const rows=[['场地','轮廓面积',area(r).toFixed(2)+' m²'],['场地','墙高',cm(r.height)+' cm'],['依据','尺寸来源',r.measured?'使用者标为已测量':'设计尺寸 / 待实测']];
 for(const w of walls(r))rows.push(['墙面',w.name,`${cm(w.length)} × ${cm(w.height)} cm`]);
 r.openings?.forEach((o,i)=>rows.push(['门窗',`${i+1} · ${o.type==='door'?'门':'窗'} · 墙 ${o.wall+1}`,`起点 ${cm(o.start)} / 宽 ${cm(o.width)} / 高 ${cm(o.height)} / 离地 ${cm(o.bottom)} cm`]));
 r.columns?.forEach((c,i)=>rows.push(['柱子',`${i+1} · ${c.shape==='box'?'方柱':'圆柱'}`,`X ${cm(c.x)} / Z ${cm(c.z)} / ${c.shape==='box'?`宽 ${cm(c.width)} 深 ${cm(c.depth)}`:`直径 ${cm(c.diameter)}`} / 高 ${cm(c.height)} cm`]));
 state.works.forEach((w,i)=>rows.push(['作品',`${i+1} · ${w.name}`,`${cm(w.width)} × ${cm(w.height)} cm · ${w.placed===false?'待布置':w.type==='art'?`${walls(r)[w.wall].name} · 中心距起点 ${cm(w.along)} · 底边离地 ${cm(w.elevation)} cm`:`X ${cm(w.x)} / Z ${cm(w.z)} cm`}`]));return rows;
}
