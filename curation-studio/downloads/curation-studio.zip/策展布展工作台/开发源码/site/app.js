import {ExhibitionScene} from './scene.js';
import {INITIAL_STATE} from './seed.js';
import {GLTFExporter} from './vendor/GLTFExporter.js';
import * as THREE from 'three';
import {setupBuilder,planSVG} from './builder.js';
import {validateArchitecture,reconcileWorks,dimensionRows} from './architecture.js';
import {MANUAL_HTML} from './manual.js';
import {FORMAT,clone,cm,clamp,uid,walls,bounds,wallPosition,workBounds,fitFrame,resizeArtwork,imageItems,contains,normalizeOutline,validateState,measuredState,sampleImage} from './model.js';

const ORIGINAL_SHELL=document.documentElement.outerHTML;
const BOOT=JSON.parse(document.getElementById('curation-state')?.textContent||'null');
const readOnly=!!BOOT?.readOnly||new URLSearchParams(location.search).get('mode')==='view';
const initialState=BOOT?.state||INITIAL_STATE;
const activeId=initialState.metadata?.projectId||'curation-primary';
const ready=()=>state.metadata?.venueReady!==false;
const $=id=>document.getElementById(id),all=selector=>[...document.querySelectorAll(selector)];
let state=clone(initialState),selected=null,shared=null,dirty=false,conflict=false,generation=0,saving=false,saveTimer,toastTimer,pendingImages=[],dragSnapshot=null,initializing=true,remoteLoading=false;
const undoStack=[],redoStack=[],assetCache=new Map();
const dbPromise=new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(Error('本机缓存暂时不可用。')),4000);
  const request=indexedDB.open('curation-studio-v1',1);
  request.onupgradeneeded=()=>request.result.createObjectStore('drafts');request.onsuccess=()=>{clearTimeout(timer);resolve(request.result);};request.onerror=()=>{clearTimeout(timer);reject(request.error);};
});
dbPromise.catch(()=>{});
async function dbGet(key){try{const db=await dbPromise;return await new Promise((resolve,reject)=>{const req=db.transaction('drafts').objectStore('drafts').get(key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}catch{return null;}}
async function dbSet(key,value){const db=await dbPromise;return new Promise((resolve,reject)=>{const tx=db.transaction('drafts','readwrite');tx.objectStore('drafts').put(value,key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}
const draftKey=()=>`draft:${readOnly?'view':'edit'}:${activeId}`;
function toast(text){clearTimeout(toastTimer);$('toast').textContent=text;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,4300);}
function status(text){$('save-status').replaceChildren();const dot=document.createElement('i');$('save-status').append(dot,document.createTextNode(text));}
function editable(){return !initializing&&!readOnly;}
async function keepRecovery(){if(ready()&&!readOnly)await dbSet('recovery:'+activeId,{state:clone(state),updated:Date.now()});}
function remember(){undoStack.push(clone(state));if(undoStack.length>20)undoStack.shift();redoStack.length=0;updateUndo();}
function updateUndo(){$('undo').disabled=!editable()||undoStack.length===0;$('redo').disabled=!editable()||redoStack.length===0;}
async function persist(){
  if(readOnly){status('只读观看 · 未修改原文件');return;}
  try{await dbSet(draftKey(),{state:clone(state),shared:shared?{...shared}:null,dirty,generation,updated:Date.now()});status(readOnly?'只看副本':'本机已保存');}
  catch{status('本机保存失败');toast('浏览器存储空间不足，请立即导出方案文件。');}
}
function changed({rebuild=true}={}){
  state.works.forEach(fitFrame);generation++;dirty=!!shared;conflict=conflict||false;
  renderUI();if(rebuild)scene.update(state);
  persist();
}
async function imageSource(source){if(source.startsWith('sample:'))return sampleImage(source.split(':')[1]);if(source.startsWith('data:image/'))return source;throw Error('方案缺少随文件携带的图片，请重新导出带图片的完整方案。');}
const scene=new ExhibitionScene($('viewport'),{
  select:id=>select(id),beginDrag:()=>{dragSnapshot=clone(state);},drag:()=>{renderInspector();},endDrag:moved=>{
    if(moved){undoStack.push(dragSnapshot);if(undoStack.length>20)undoStack.shift();redoStack.length=0;changed({rebuild:false});}dragSnapshot=null;
  },imageSource
});
$('viewport').addEventListener('render-error',()=>toast('三维显示暂时中断，请导出方案备份后刷新页面。'));
function select(id){selected=id;scene.setSelected(id);renderUI();$('inspector').classList.toggle('open',!!id);}
function renderUI(){
  $('project-title').value=state.title;document.title=state.title+' · 布展';$('sample-notice').hidden=false;
  $('sample-notice').textContent=(readOnly?'只读观看 · ':'')+(state.room.measured?'场地尺寸由使用者标为已测量':'场地尺寸为使用者设定 · 待现场核对');
  $('start-screen').hidden=ready();$('workspace').hidden=!ready();document.body.classList.toggle('venue-empty',!ready());document.body.classList.toggle('read-only',readOnly);
  for(const id of ['dimensions-open','export-open','share-open','project-title'])$(id).disabled=!ready();
  $('viewer-project-text').textContent=[state.metadata?.author,state.metadata?.entryCode,state.metadata?.description].filter(Boolean).join('\n\n');
  const b=bounds(state.room);$('room-summary').textContent=`${b.width.toFixed(2)} × ${b.depth.toFixed(2)}m · 墙高 ${state.room.height.toFixed(2)}m`;
  const placed=state.works.filter(w=>w.placed!==false).length;$('work-count').textContent=`${state.works.length} 件${placed<state.works.length?' · 已布置 '+placed:''}`;$('work-list').replaceChildren();
  if(!state.works.length){const empty=document.createElement('p');empty.className='empty-list';empty.textContent='场地已就绪。\n添加第一件作品，开始布展。';$('work-list').append(empty);}
  state.works.forEach((w,i)=>{
    const button=document.createElement('button');button.className='work-item'+(w.id===selected?' selected':'');button.dataset.workId=w.id;
    const thumb=document.createElement('span');thumb.className='work-thumb';
    if(w.image){const img=document.createElement('img');img.alt='';img.loading='lazy';img.decoding='async';imageSource(w.thumbnail||w.image).then(url=>img.src=url).catch(()=>{thumb.textContent='图片';});thumb.append(img);}else {const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('fill','none');icon.setAttribute('stroke','currentColor');icon.innerHTML=w.type==='partition'?'<path d="M4 5h16v14H4Z"/>':'<path d="m12 3 9 5v9l-9 5-9-5V8Zm0 10 9-5m-9 5L3 8m9 5v9"/>';thumb.append(icon);}
    const info=document.createElement('span');info.className='work-item-info';const name=document.createElement('span');name.className='work-item-name';name.textContent=w.name;
    const size=document.createElement('small');size.textContent=w.placed===false?'待布置 · 点击选择':`${cm(w.width)} × ${cm(w.height)} cm${w.type==='art'?' · '+(walls(state.room)[w.wall]?.name||'墙面'):''}`;info.append(name,size);
    const number=document.createElement('span');number.className='work-number';number.textContent=String(i+1).padStart(2,'0');button.append(thumb,info,number);button.onclick=()=>select(w.id);$('work-list').append(button);
  });
  const wallOptions=walls(state.room);for(const id of ['work-wall','add-wall']){const previous=$(id).value;$(id).replaceChildren(...wallOptions.map(w=>new Option(`${w.name} · ${w.length.toFixed(2)} m`,w.index)));if(previous&&wallOptions[Number(previous)])$(id).value=previous;}
  $('wall-views').replaceChildren(...wallOptions.map(w=>{const button=document.createElement('button');button.textContent=w.name;button.dataset.view=`wall:${w.index}`;button.className=scene.mode===button.dataset.view?'active':'';button.onclick=()=>changeView(button.dataset.view);return button;}));
  $('conflict-banner').hidden=!conflict;renderInspector();updateUndo();
  for(const id of ['add-art','add-plinth','add-block','add-partition','room-open','project-title','duplicate','delete-work','work-placement','project-info-open'])$(id).disabled=!editable()||!ready();
  $('inspector-selected').querySelectorAll('input,select').forEach(el=>el.disabled=!editable());
}
function renderInspector(){
  const w=state.works.find(w=>w.id===selected);$('inspector-empty').hidden=!!w;$('inspector-selected').hidden=!w;if(!w)return;
  $('selected-number').textContent=String(state.works.indexOf(w)+1).padStart(2,'0');
  const fields={'work-name':w.name,'work-width':cm(w.width),'work-height':cm(w.height),'work-depth':cm(w.depth),'work-elevation':cm(w.elevation),'work-rotation':Math.round(w.rotation),'work-x':cm(w.x),'work-z':cm(w.z),'work-along':cm(w.along||0),'work-wall':w.wall??0,'work-frame':w.frame||'none','work-frame-width':cm(w.frameWidth??.008),'work-mat':cm(w.mat||0)};
  const rb=bounds(state.room);fields['work-x']=cm(w.x);fields['work-z']=cm(w.z);
  Object.entries(fields).forEach(([id,value])=>{if(document.activeElement!==$(id))$(id).value=value;});
  const isArt=w.type==='art';$('wall-fields').hidden=!isArt;$('floor-fields').hidden=isArt;$('frame-fields').hidden=!isArt;$('rotation-label').hidden=isArt;
  $('aspect-lock-control').hidden=!isArt;$('work-lock-aspect').checked=w.lockAspect!==false;
  $('work-placement').hidden=!isArt;$('work-placement').textContent=w.placed===false?'挂到所选墙面':'收回作品清单';$('work-placement').classList.toggle('primary',w.placed===false);
  $('mat-label').hidden=!isArt||w.frame==='none';$('frame-width-label').hidden=!isArt||w.frame==='none';const outer=workBounds(w);$('frame-note').textContent=`画面尺寸 ${cm(w.width)} × ${cm(w.height)} cm${w.frame!=='none'?` · 框条 ${cm(w.frameWidth??.008)} cm · 含框 ${cm(outer.width)} × ${cm(outer.height)} cm`:''}`;
  $('frame-outer-fields').hidden=!isArt||w.frame==='none';$('frame-outer-width').value=cm(outer.width);$('frame-outer-height').value=cm(outer.height);
  $('selected-preview').replaceChildren();if(w.image){const img=document.createElement('img');img.alt=w.name;imageSource(w.image).then(url=>img.src=url).catch(()=>{});$('selected-preview').append(img);}else{const box=document.createElement('div');box.className='preview-block';$('selected-preview').append(box);}
  const wall=isArt?walls(state.room)[w.wall]:null;let warning='';
  if(wall&&(outer.width>wall.length||outer.height>wall.height))warning='作品超过这面墙的可用尺寸，请调整尺寸或换一面墙。';
  if(wall&&(state.room.openings||[]).some(o=>o.wall===w.wall&&w.along+outer.width/2>o.start&&w.along-outer.width/2<o.start+o.width&&w.elevation+outer.height>o.bottom&&w.elevation<o.bottom+o.height))warning='作品与门窗位置重叠，请调整位置。';
  if(wall&&(state.room.wallSurfaceSteps||[]).some(s=>s.wall===w.wall&&Math.abs(w.along-s.along)<outer.width/2))warning='作品横跨了墙面接缝 / 小台阶，请向一侧移动。';
  if(!isArt&&!contains(state.room,w.x,w.z))warning='作品中心在展厅轮廓之外，请调整位置。';
  $('work-warning').textContent=warning;$('work-warning').hidden=!warning||w.placed===false;
}
function changeView(mode){if(mode==='eye')select(null);scene.view(mode);$('walk-controls').hidden=mode!=='eye';$('wall-views').hidden=mode==='eye';all('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===mode));$('view-tip').textContent=readOnly?(mode==='eye'?'拖动画面环顾 · 点击移动按钮':mode.startsWith('wall:')?'正视这面墙 · 滚轮缩放':'拖动转动视角 · 滚轮缩放 · 只读观看'):mode==='plan'?'选中作品后拖动位置 · 滚轮缩放':mode==='eye'?'拖动画面环顾 · 点击移动按钮 · 也支持方向键 / W A S D':mode.startsWith('wall:')?'正视这面墙 · 拖动作品调整挂画位置':'拖动画面转动视角 · 滚轮缩放 · 选中作品后拖动摆放';}
for(const button of all('[data-walk]')){
  const direction=button.dataset.walk,step=()=>scene.moveEye(direction==='forward'?1:direction==='back'?-1:0,direction==='right'?1:direction==='left'?-1:0);
  button.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();step();scene.navigation.add(direction);button.setPointerCapture(e.pointerId);});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,()=>scene.navigation.delete(direction));
  button.onclick=e=>{if(e.detail===0)step();};
}
all('.view-switch [data-view]').forEach(button=>button.onclick=()=>changeView(button.dataset.view));
$('reset-view').onclick=()=>changeView(scene.mode);$('grid-toggle').onclick=()=>{scene.gridVisible=!scene.gridVisible;scene.applyVisibility();};
$('undo').onclick=()=>{if(!undoStack.length||!editable())return;redoStack.push(clone(state));state=undoStack.pop();changed();select(state.works.some(w=>w.id===selected)?selected:null);};
$('redo').onclick=()=>{if(!redoStack.length||!editable())return;undoStack.push(clone(state));state=redoStack.pop();changed();};
window.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)||document.querySelector('dialog[open]'))return;if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='z'){e.preventDefault();$(e.shiftKey?'redo':'undo').click();}if(e.key==='Escape')select(null);});
$('project-title').onchange=()=>{if(!editable())return;remember();state.title=$('project-title').value.trim()||'我的个展';changed({rebuild:false});};
const fieldMap={'work-width':'width','work-height':'height','work-depth':'depth','work-elevation':'elevation','work-x':'x','work-z':'z','work-along':'along','work-rotation':'rotation'};
function resizePhoto(work,field,value){
  const resized=clone(work);if(!resizeArtwork(resized,field,value)){renderInspector();$('work-width').value=cm(work.width);$('work-height').value=cm(work.height);return;}
  remember();for(const key of ['width','height','frameOuterWidth','frameOuterHeight','imageRatio']){if(key in resized)work[key]=resized[key];else delete work[key];}
  wallPosition(work,state.room);changed();$('work-width').value=cm(work.width);$('work-height').value=cm(work.height);
  const outer=workBounds(work);$('frame-outer-width').value=cm(outer.width);$('frame-outer-height').value=cm(outer.height);
}
Object.entries(fieldMap).forEach(([id,field])=>$(id).onchange=()=>{
  const w=state.works.find(w=>w.id===selected);if(!w||!editable()||!$(id).value.trim())return;let val=Number($(id).value);if(!Number.isFinite(val))return;
  if(w.type==='art'&&['width','height'].includes(field)){resizePhoto(w,field,val/100);return;}
  if(['width','height','depth'].includes(field))val=clamp(val,field==='depth'?.05:.5,3000);if(field==='elevation')val=clamp(val,0,3000);remember();w[field]=field==='rotation'?val:val/100;
  const rb=bounds(state.room);
  if(w.type==='art')wallPosition(w,state.room);changed();
});
$('work-lock-aspect').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||w.type!=='art'||!editable())return;remember();w.lockAspect=$('work-lock-aspect').checked;changed({rebuild:false});};
$('work-mat').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;const val=Number($('work-mat').value);if(!Number.isFinite(val))return;remember();w.mat=clamp(val,0,15)/100;changed();};
$('work-frame-width').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;const val=Number($('work-frame-width').value);if(!Number.isFinite(val))return;remember();w.frameWidth=clamp(val,.2,15)/100;changed();};
for(const [id,field] of [['frame-outer-width','frameOuterWidth'],['frame-outer-height','frameOuterHeight']])$(id).onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable()||!$(id).value.trim())return;const val=Number($(id).value);if(!Number.isFinite(val))return;resizePhoto(w,field,val/100);};
$('work-name').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;remember();w.name=$('work-name').value.trim()||'未命名作品';changed({rebuild:false});};
$('work-wall').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;remember();w.wall=Number($('work-wall').value);w.along=walls(state.room)[w.wall].length/2;wallPosition(w,state.room);changed();};
$('work-frame').onchange=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;remember();w.frame=$('work-frame').value;changed();};
$('work-placement').onclick=()=>{const w=state.works.find(w=>w.id===selected);if(!w||w.type!=='art'||!editable())return;remember();w.placed=w.placed===false;wallPosition(w,state.room);if(w.placed&&scene.mode==='eye')changeView('overview');changed();select(w.id);toast(w.placed?'作品已挂到所选墙面，可拖动调整位置。':'已收回作品清单，图片仍保留。');};
$('duplicate').onclick=()=>{const w=state.works.find(w=>w.id===selected);if(!w||!editable())return;if(state.works.length>=200){toast('每个方案最多保留 200 个布展对象，请先移除一些对象。');return;}remember();const copy=clone(w);copy.id=uid();copy.name+=' · 副本';if(copy.type==='art'){copy.along+=copy.width+.2;wallPosition(copy,state.room);}else{copy.x+=.3;copy.z+=.3;}state.works.push(copy);selected=copy.id;changed();scene.setSelected(selected);};
$('delete-work').onclick=()=>{if(!selected||!editable())return;remember();state.works=state.works.filter(w=>w.id!==selected);select(null);changed();};
function addVolume(type){if(!editable())return;if(state.works.length>=200){toast('每个方案最多保留 200 个布展对象，请先移除一些对象。');return;}remember();const b=bounds(state.room),work={id:uid(),type,name:{plinth:'新展台',block:'装置体块',partition:'新隔墙'}[type],width:type==='partition'?2:1,height:type==='plinth'?.9:type==='partition'?2.5:1.4,depth:type==='partition'?.12:.6,elevation:0,x:b.cx,z:b.cz,rotation:0};state.works.push(work);selected=work.id;changed();select(selected);}
$('add-plinth').onclick=()=>addVolume('plinth');$('add-block').onclick=()=>addVolume('block');$('add-partition').onclick=()=>builder.open({section:'inner'});
function open(id){$(id).showModal();}all('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());all('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
const mobileClose=document.createElement('button');mobileClose.innerHTML='<svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 6l12 12M18 6 6 18"/></svg>';mobileClose.className='mobile-inspector-close';mobileClose.setAttribute('aria-label','关闭作品设置');mobileClose.onclick=()=>{$('inspector').classList.remove('open');};$('inspector').prepend(mobileClose);
function blobDataURL(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});}
async function resizeImage(file){
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('请使用 JPG、PNG 或 WebP 图片。HEIC 可先在“预览”中导出为 JPG。');
  if(file.size>50*1024*1024)throw Error('单张图片请控制在 50 MB 以内。');
  const originalURL=URL.createObjectURL(file);try{
    const image=new Image();image.src=originalURL;await image.decode();const ratio=image.naturalWidth/image.naturalHeight,scale=Math.min(1,1600/image.naturalWidth,1600/image.naturalHeight);
    const c=document.createElement('canvas');c.width=Math.max(1,Math.round(image.naturalWidth*scale));c.height=Math.max(1,Math.round(image.naturalHeight*scale));const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(image,0,0,c.width,c.height);
    return {name:file.name.replace(/\.[^.]+$/,''),ratio,image:c.toDataURL('image/jpeg',.9)};
  }finally{URL.revokeObjectURL(originalURL);}
}
$('add-art').onclick=()=>$('image-input').click();$('image-input').onchange=async()=>{
  const files=[...$('image-input').files];$('image-input').value='';if(!files.length)return;
  try{status('正在读取图片…');pendingImages=[];for(const file of files)pendingImages.push(await resizeImage(file));$('add-thumbnails').replaceChildren(...pendingImages.map(p=>{const img=document.createElement('img');img.src=p.image;img.alt=p.name;return img;}));$('add-wall').value=state.works.find(w=>w.id===selected)?.wall??0;$('add-unplaced').checked=files.length>1;$('confirm-add').textContent=files.length>1?'加入作品清单':'放入展厅';open('add-dialog');status(shared?'共享方案':'本机已保存');}
  catch(err){toast(err.message);status('图片未添加');}
};
$('confirm-add').onclick=()=>{
  if(!editable())return;const width=Number($('add-width').value)/100,elevation=Number($('add-elevation').value)/100,wall=Number($('add-wall').value);
  if(!Number.isFinite(width)||width<.01||width>30||!Number.isFinite(elevation)||elevation<0){toast('请填写有效的作品宽度和离地高度。');return;}
  if(state.works.length+pendingImages.length>200){toast('单个方案最多放入 200 件作品。');return;}remember();const wallData=walls(state.room)[wall],offset=(pendingImages.length-1)*(width+.25)/2;
  pendingImages.forEach((p,i)=>{const work={id:uid(),name:p.name,type:'art',image:p.image,placed:!$('add-unplaced').checked,width:Math.min(width,30*p.ratio),height:Math.min(30,width/p.ratio),depth:.03,elevation,wall,along:wallData.length/2-offset+i*(width+.25),rotation:0,x:0,z:0,frame:'none'};wallPosition(work,state.room);state.works.push(work);selected=work.id;});pendingImages=[];$('add-dialog').close();changed();select(selected);
};
$('add-unplaced').onchange=()=>{$('confirm-add').textContent=$('add-unplaced').checked?'加入作品清单':'放入展厅';};
const builder=setupBuilder({getState:()=>state,onApply:room=>{if(!editable())return;const remap=reconcileWorks(state.room,room,state.works),proposed=clone(state);proposed.room=room;proposed.works=remap.works;proposed.metadata={...proposed.metadata,venueReady:true};const valid=validateState(proposed);remember();state=valid;selected=null;scene.mode='overview';changed();scene.resize();changeView('overview');toast(remap.returned?`已保存场地，${remap.returned} 件作品的原墙已移除，已收回待布置清单。`:'场地已保存，可以开始布展。');}});
$('room-open').onclick=()=>{if(editable())builder.open();};
$('start-create').onclick=()=>builder.open();
$('start-import').onclick=()=>$('project-input').click();
$('start-help').onclick=()=>$('help-open').click();
const viewerText=document.createElement('p');viewerText.id='viewer-project-text';viewerText.className='viewer-project-text';$('work-list').after(viewerText);
$('project-info-open').onclick=()=>{for(const [id,value] of [['info-title',state.title],['info-author',state.metadata?.author||''],['info-code',state.metadata?.entryCode||''],['info-description',state.metadata?.description||'']])$(id).value=value;open('project-info-dialog');};
$('project-info-form').onsubmit=e=>{e.preventDefault();if(!editable())return;remember();state.title=$('info-title').value.trim()||'未命名展览';state.metadata={...state.metadata,author:$('info-author').value.trim(),entryCode:$('info-code').value.trim(),description:$('info-description').value.trim()};changed({rebuild:false});$('project-info-dialog').close();};
$('manual-content').innerHTML=MANUAL_HTML;
$('help-open').onclick=()=>open('help-dialog');
$('recover-project').onclick=async()=>{if(!editable())return;const backup=await dbGet('recovery:'+activeId);if(!backup){toast('还没有可恢复的上一个草稿。');return;}const recovered=validateState(backup.state);await keepRecovery();state=recovered;selected=null;undoStack.length=0;redoStack.length=0;scene.mode='overview';changed();scene.resize();scene.view('overview');$('files-dialog').close();toast('已恢复上一个草稿；刚才的草稿也已存为恢复副本。');};
function filename(suffix){return (state.title||'布展方案').replace(/[\\/:*?"<>|]/g,'_')+suffix;}
async function download(blob,name){
  document.querySelectorAll('dialog[open]').forEach(dialog=>dialog.close());
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.textContent='保存文件';a.className='download-ready';
  document.querySelectorAll('.download-ready').forEach(link=>link.remove());document.body.append(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(url);},600000);
}
async function portableState(){const copy=clone(state);for(const w of imageItems(copy))for(const field of ['image','thumbnail'])if(w[field]?.startsWith('asset:'))w[field]=await imageSource(w[field]);return copy;}
async function exportProject(){try{const copy=await portableState();await download(new Blob([JSON.stringify(copy,null,2)],{type:'application/json'}),filename('_布展方案.json'));toast('方案文件已生成。若未开始下载，点击“保存文件”。');return true;}catch(err){toast('导出失败：'+err.message);return false;}}
$('file-menu').onclick=()=>open('files-dialog');$('download-project').onclick=exportProject;$('share-file-export').onclick=exportProject;
$('import-project').onclick=()=>$('project-input').click();$('project-input').onchange=async()=>{
  const file=$('project-input').files[0];$('project-input').value='';if(!file)return;
  try{if(file.size>200*1024*1024)throw Error('方案文件过大。');const loaded=validateState(JSON.parse(await file.text()));if(!loaded.room.wallColor)loaded.room.wallColor='#ffffff';if(!loaded.room.floorColor)loaded.room.floorColor='#deded8';loaded.room.columns||=[];loaded.room.openings||=[];loaded.room.interiorWalls||=[];loaded.room=validateArchitecture(loaded.room);if(imageItems(loaded).some(w=>[w.image,w.thumbnail].some(i=>i?.startsWith('asset:'))))throw Error('这份文件没有携带图片，请从原工作台重新导出完整方案。');await keepRecovery();shared=null;dirty=false;conflict=false;loaded.metadata={...loaded.metadata,venueReady:true};state=loaded;selected=null;undoStack.length=0;redoStack.length=0;if(location.protocol!=='file:')history.replaceState(null,'',location.pathname+(readOnly?'?mode=view':'')); assetCache.clear();$('files-dialog').close();scene.mode='overview';changed();scene.resize();changeView('overview');toast(readOnly?'已打开方案供观看，原文件未修改。':'已导入为本机方案。');}
  catch(err){toast('导入失败：'+err.message);}
};
$('export-open').onclick=()=>open('export-dialog');
function caption(canvas,label){
  if(!$('export-label').checked)return canvas;const margin=Math.round(canvas.width*.045),header=Math.round(canvas.width*.068),footer=Math.round(canvas.width*.05),output=document.createElement('canvas');output.width=canvas.width;output.height=canvas.height+header+footer;const c=output.getContext('2d');c.fillStyle='#f9f8f3';c.fillRect(0,0,output.width,output.height);c.drawImage(canvas,0,header);c.fillStyle='#2d4034';c.font=`500 ${Math.round(canvas.width*.015)}px -apple-system, "PingFang SC", sans-serif`;c.fillText(state.title,margin,header*.55);c.textAlign='right';c.fillStyle='#7a8076';c.font=`${Math.round(canvas.width*.009)}px -apple-system, "PingFang SC", sans-serif`;c.fillText(label,canvas.width-margin,header*.55);c.textAlign='left';const b=bounds(state.room);c.fillText(`制作者 姜昕宇 · 场地 ${b.width.toFixed(2)} × ${b.depth.toFixed(2)} m  ·  周边可用墙高 ${state.room.height.toFixed(2)} m  ·  ${state.works.length} 件作品${state.room.provisional?'  ·  部分尺寸待确认':''}`,margin,output.height-footer*.45);return output;
}
async function canvasBlob(canvas){return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('图片生成失败。')),'image/png'));}
$('confirm-export').onclick=async()=>{
  const button=$('confirm-export'),mode=$('export-mode').value,width=Number($('export-size').value),oldMode=scene.mode,oldPosition=scene.camera.position.clone(),oldTarget=scene.controls.target.clone();button.disabled=true;button.textContent='正在生成…';
  try{
    const outputs=[];
    if(mode==='walls'){for(const wall of walls(state.room)){scene.view(`wall:${wall.index}`);outputs.push(caption(await scene.capture(width),`${wall.name} · ${wall.length.toFixed(2)} × ${wall.height.toFixed(2)} m`));}}
    else{if(mode==='plan')scene.view('plan');outputs.push(caption(await scene.capture(width),mode==='plan'?'俯视布置图':oldMode.startsWith('wall:')?walls(state.room)[Number(oldMode.split(':')[1])].name:oldMode==='eye'?'观众视角':'空间总览'));}
    let output=outputs[0];if(outputs.length>1){const total=outputs.reduce((n,c)=>n+c.height,0);if(total>30000)throw Error('长图超出浏览器限制，请降低导出宽度。');output=document.createElement('canvas');output.width=width;output.height=total;let y=0;const ctx=output.getContext('2d');for(const c of outputs){ctx.drawImage(c,0,y);y+=c.height;}}
    await download(await canvasBlob(output),filename(mode==='walls'?'_各墙正视图.png':mode==='plan'?'_俯视布置.png':'_空间效果.png'));$('export-dialog').close();toast('PNG 已生成。若未开始下载，点击“保存文件”。');
  }catch(err){toast('导出失败：'+err.message);}
  finally{scene.view(oldMode);scene.camera.position.copy(oldPosition);scene.controls.target.copy(oldTarget);scene.controls.update();button.disabled=false;button.textContent='导出 PNG';}
};

$('share-open').onclick=()=>open('share-dialog');
$('share-editable').onclick=()=>exportPortable(false);
$('share-viewer').onclick=()=>exportPortable(true);
$('copy-entry').onclick=async()=>{const url='https://13864768492jxy-create.github.io/once-exhibition-viewer/curation-studio/';try{await navigator.clipboard.writeText(url);toast('已复制工作台入口。当前方案请另存 HTML 或 JSON 分享。');}catch{$('entry-link').value=url;$('entry-link').focus();$('entry-link').select();}};

async function exportPortable(viewOnly){
 const button=$(viewOnly?'share-viewer':'share-editable');button.disabled=true;status('正在打包图片与空间…');
 try{
   const packed=await portableState();packed.metadata={...packed.metadata,projectId:uid()};
   const doc=new DOMParser().parseFromString('<!doctype html>'+ORIGINAL_SHELL,'text/html');
   const script=doc.getElementById('app-bundle');
   const code=script.getAttribute('src')?await fetch(new URL(script.getAttribute('src'),location.href)).then(r=>{if(!r.ok)throw Error('无法读取网页程序，请使用本地完整版本。');return r.text();}):script.textContent;
   const link=doc.querySelector('link[data-app-style]');
   if(link){const css=await fetch(new URL(link.getAttribute('href'),location.href)).then(r=>{if(!r.ok)throw Error('无法读取样式。');return r.text();});const style=doc.createElement('style');style.textContent=css;link.replaceWith(style);}
   doc.querySelectorAll('script:not(#curation-state):not(#app-bundle)').forEach(el=>el.remove());
   script.removeAttribute('src');script.removeAttribute('defer');script.textContent=code;
   doc.getElementById('curation-state').textContent=JSON.stringify({readOnly:viewOnly,state:packed}).replace(/</g,'\\u003c');
   doc.title=packed.title+(viewOnly?' · 只看副本':' · 可编辑方案');
   await download(new Blob(['<!doctype html>\n'+doc.documentElement.outerHTML],{type:'text/html;charset=utf-8'}),filename(viewOnly?'_只看副本.html':'_可编辑方案.html'));
   toast('已生成单文件网页。把这个HTML发给对方，用电脑浏览器打开即可。');
 }catch(err){toast('打包失败：'+err.message);}finally{button.disabled=false;status(readOnly?'只看副本':'本机已保存');}
}

async function exportModel(){
 const button=$('model-export');button.disabled=true;status('正在导出完整模型…');
 try{
   scene.workGroups.forEach(g=>scene.upgradeArt(g));await Promise.all([...scene.loadingTextures]);
   const out=new THREE.Scene();out.name='Curatorial_Exhibition';
   const room=scene.roomGroup.clone(true);room.name='User_Venue';
   const remove=[];room.traverse(o=>{if(o.isSprite||o.type==='GridHelper'||o.userData.stepAnnotation||o.userData.wallLabel)remove.push(o);else o.visible=true;});remove.forEach(o=>o.removeFromParent());
   const works=scene.worksGroup.clone(true);works.name='Curatorial_Layout';const markers=[];works.traverse(o=>{if(o.userData.marker||o.isSprite)markers.push(o);else o.visible=true;});markers.forEach(o=>o.removeFromParent());
   const b=bounds(state.room);room.position.set(-b.minX,0,-b.minZ);works.position.copy(room.position);out.add(room,works);
   out.userData={units:'metres',coordinates:'X=plan-right,Y=up,Z=plan-down',origin:'minimum X and Z of venue outline at floor',maker:'制作者 姜昕宇'};
   let index=0;out.traverse(o=>{if(!o.name)o.name=o.userData.wallIndex!==undefined?'Wall_'+(o.userData.wallIndex+1)+'_'+index:o.type+'_'+index;index++;});
   const binary=await new GLTFExporter().parseAsync(out,{binary:true,onlyVisible:false,maxTextureSize:2048});
   await download(new Blob([binary],{type:'model/gltf-binary'}),filename('_米制模型.glb'));toast('GLB模型已导出，单位为米；包含完整建筑和已摆放作品。');
 }catch(err){toast('模型导出失败：'+err.message);}finally{button.disabled=false;status(readOnly?'只看副本':'本机已保存');}
}
$('model-export').onclick=exportModel;
$('empty-new').onclick=async()=>{if(!editable())return;if(ready()&&!confirm('新建另一场展览？当前草稿会保留在“恢复上一个草稿”中，重要方案请先导出。'))return;await keepRecovery();remember();state=clone(INITIAL_STATE);selected=null;changed();$('files-dialog').close();status('从自己的场地开始');};
$('dimensions-open').onclick=()=>{renderDimensions();open('dimensions-dialog');};
function renderDimensions(){
 $('dimension-plan').innerHTML=planSVG(state.room).svg.replaceAll('builder-plan-svg','dimension-plan-svg').replaceAll('wall-direction','dimension-wall-direction');$('dimension-table').replaceChildren();const rows=dimensionRows(state),table=document.createElement('table');const head=document.createElement('thead');head.innerHTML='<tr><th>类别</th><th>部位 / 作品</th><th>尺寸与位置</th></tr>';table.append(head);const body=document.createElement('tbody');for(const row of rows){const tr=document.createElement('tr');for(const cell of row){const td=document.createElement('td');td.textContent=cell;tr.append(td);}body.append(tr);}table.append(body);$('dimension-table').append(table);
}
$('dimension-csv').onclick=async()=>{const esc=s=>'"'+String(s).replaceAll('"','""')+'"';const rows=[['类别','部位 / 作品','尺寸与位置'],...dimensionRows(state)];await download(new Blob(['\ufeff'+rows.map(r=>r.map(esc).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),filename('_尺寸清单.csv'));};
$('dimension-print').onclick=()=>{renderDimensions();window.print();};
$('model-empty-note').textContent='模型含完整墙体与已布置作品，单位为米；当前剖切视角不会删掉墙。';
if(readOnly){$('start-screen').querySelector('h1').textContent='打开一个展览方案';$('start-screen').querySelector('.start-intro > p').textContent='选择对方发来的 JSON 文件，即可在浏览器中观看。文件只在本机读取。';$('start-create').hidden=true;$('start-import').textContent='选择方案 JSON';$('viewer-entry').textContent='返回编辑工作台';$('viewer-entry').href=location.pathname;$('start-screen').querySelector('.start-footnote').innerHTML='在本机读取 · 不修改原文件<br>制作者 姜昕宇';}
async function initialize(){
 initializing=true;
 try{
   const cached=readOnly?null:await dbGet(draftKey());if(cached){try{state=validateState(cached.state);}catch{}}
   state=validateState(state);scene.update(state);if(ready())scene.view('overview');$('loading').hidden=true;
 }finally{
   initializing=false;scene.editable=editable();renderUI();if(readOnly){$('empty-new').disabled=true;$('recover-project').disabled=true;$('share-editable').disabled=true;status('只读观看');}else await persist();scene.resize();if(ready())scene.view('overview');
 }
}
initialize().catch(err=>{$('loading').textContent='打开失败：'+err.message;toast('请尝试重新打开完整HTML或导入有效方案。');});
