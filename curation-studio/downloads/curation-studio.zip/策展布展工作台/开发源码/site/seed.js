// Hidden internal placeholder, not a supplied venue or an exhibited work.
export const INITIAL_STATE={format:'exhibition-planner-v1',title:'未命名展览',metadata:{projectId:'curation-primary',venueReady:false,author:'',description:''},room:{points:[[0,0],[1,0],[1,1],[0,1]],height:3,measured:false,wallColor:'#ffffff',floorColor:'#deded8',openings:[],interiorWalls:[],columns:[]},works:[]};
